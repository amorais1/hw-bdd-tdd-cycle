require 'rails_helper'

RSpec.describe MoviesControllerController, type: :controller do

end
